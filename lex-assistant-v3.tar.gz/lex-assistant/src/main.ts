/**
 * main.ts — Module 1: Dossiers
 *
 * State lives entirely on OneDrive as JSON files.
 * No IndexedDB. No local persistence except:
 *   - localStorage: API key + OneDrive config (credentials only)
 *   - sessionStorage: MSAL token cache (managed by MSAL)
 *
 * Per-case OneDrive files:
 *   Affaires/<folderName>/_meta.json         ← CaseMeta
 *   Affaires/<folderName>/_notes.json        ← PermanentNote[]
 *   Affaires/<folderName>/_conversation.json ← ChatMessage[]
 *   Affaires/<folderName>/<file>             ← actual documents
 */

import type {
  LexCase, CaseMeta, CaseDocumentMeta,
  PermanentNote, ChatMessage, WorkMode
} from './types.js';
import { callClaudeCase, getStoredKey, setStoredKey, clearStoredKey } from './modules/api.js';
import { generateDocx, downloadBlob } from './modules/docxgen.js';
import { renderMarkdown } from './modules/markdown.js';
import { qs, qsa, el, toggle, setActive, toast, confirm, spinnerEl, uid, formatDate, formatDateTime } from './modules/ui.js';
import { makeCaseDocMeta, formatSize, kindLabel, mimeIcon, mimeLabel, guessKind, isSupported } from './modules/ingest.js';
import * as od from './modules/onedrive.js';
import { bootLib, syncSkills as syncLibSkills } from './module2.js';

// ─── App state (in-memory cache of OneDrive JSON) ─────────────────────────────

let cases: LexCase[]            = [];   // loaded from _meta.json of each case folder
let activeCase: LexCase | null  = null;
let caseNotes: PermanentNote[]  = [];
let caseMessages: ChatMessage[] = [];
let activeMode: WorkMode        = 'analyse';
let skills: Array<{ name: string; content: string }> = [];
let oneDriveUser: string | null = null;
let saving = false;  // debounce concurrent writes

// ─── Boot ─────────────────────────────────────────────────────────────────────

async function boot(): Promise<void> {
  setupModuleTabs();
  setupTopbar();
  setupSidebar();
  setupModeBar();
  setupInputArea();

  // Try silent OneDrive sign-in
  if (od.isConfigured()) {
    const signed = await od.isSignedIn();
    if (signed) {
      oneDriveUser = od.getSignedInUser();
      updateODStatus();
      await loadAllCases();
      loadSkills();
    } else {
      showNotConnected();
    }
  } else {
    showNotConnected();
  }

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
}

// ─── Load all cases ───────────────────────────────────────────────────────────

async function loadAllCases(): Promise<void> {
  const folders = await od.listCaseFolders();
  cases = [];

  await Promise.all(folders.map(async folderName => {
    const meta = await od.readCaseMeta(folderName);
    if (!meta) return;
    cases.push({
      folderName,
      name:      meta.name,
      domain:    meta.domain,
      status:    meta.status,
      createdAt: meta.createdAt,
      updatedAt: meta.updatedAt,
      documents: meta.documents ?? [],
    });
  }));

  cases.sort((a, b) => b.updatedAt - a.updatedAt);
  renderCaseList();

  if (cases.length > 0) await selectCase(cases[0].folderName);
  else showEmptyState();
}

// ─── Select case ──────────────────────────────────────────────────────────────

async function selectCase(folderName: string): Promise<void> {
  const c = cases.find(x => x.folderName === folderName);
  if (!c) return;
  activeCase    = c;
  caseNotes     = await od.readNotes(folderName);
  caseMessages  = await od.readConversation(folderName);

  qsa<HTMLElement>('.case-item').forEach(el => el.classList.toggle('active', el.dataset.folder === folderName));
  qs<HTMLElement>('#topbar-case-name').textContent   = c.name;
  qs<HTMLElement>('#topbar-case-domain').textContent = c.domain;

  renderNoteBar();
  renderDocList();
  renderChat();
  updateDocCount();
}

// ─── Persist helpers ──────────────────────────────────────────────────────────

async function saveMeta(): Promise<void> {
  if (!activeCase || saving) return;
  saving = true;
  const meta: CaseMeta = {
    name:      activeCase.name,
    folderName:activeCase.folderName,
    domain:    activeCase.domain,
    status:    activeCase.status,
    createdAt: activeCase.createdAt,
    updatedAt: Date.now(),
    documents: activeCase.documents,
  };
  activeCase.updatedAt = meta.updatedAt;
  try { await od.writeCaseMeta(activeCase.folderName, meta); }
  finally { saving = false; }
}

async function saveNotes(): Promise<void> {
  if (!activeCase) return;
  await od.writeNotes(activeCase.folderName, caseNotes);
}

async function saveConversation(): Promise<void> {
  if (!activeCase) return;
  await od.writeConversation(activeCase.folderName, caseMessages);
}

// ─── Module tabs ──────────────────────────────────────────────────────────────

function setupModuleTabs(): void {
  qs<HTMLButtonElement>('#tab-dossiers').onclick    = () => switchModule('dossiers');
  qs<HTMLButtonElement>('#tab-bibliotheque').onclick = () => switchModule('bibliotheque');
}

function switchModule(mod: 'dossiers' | 'bibliotheque'): void {
  const p1 = qs<HTMLElement>('#panel-dossiers');
  const p2 = qs<HTMLElement>('#panel-bibliotheque');
  toggle(p1, mod === 'dossiers');
  toggle(p2, mod === 'bibliotheque');
  qs<HTMLButtonElement>('#tab-dossiers').classList.toggle('active', mod === 'dossiers');
  qs<HTMLButtonElement>('#tab-bibliotheque').classList.toggle('active', mod === 'bibliotheque');

  if (mod === 'bibliotheque') {
    const c = qs<HTMLElement>('#panel-bibliotheque');
    if (!c.dataset.booted) { bootLib(c); c.dataset.booted = '1'; }
  }
}

// ─── OneDrive ─────────────────────────────────────────────────────────────────

function updateODStatus(): void {
  const el = document.getElementById('onedrive-status');
  if (!el) return;
  if (oneDriveUser) {
    el.textContent = `☁ ${oneDriveUser}`;
    el.className = 'od-status od-status--connected';
  } else {
    el.textContent = od.isConfigured() ? '☁ Non connecté' : '☁ Non configuré';
    el.className = 'od-status od-status--disconnected';
  }
}

async function loadSkills(): Promise<void> {
  skills = await od.loadSkills().catch(() => []);
  const badge = document.getElementById('skills-badge');
  if (badge) {
    badge.textContent = skills.length > 0 ? `${skills.length} skill${skills.length > 1 ? 's' : ''}` : '';
    toggle(badge as HTMLElement, skills.length > 0);
  }
  syncLibSkills(skills);
}

async function connectOneDrive(): Promise<void> {
  try {
    await od.signIn();
    oneDriveUser = od.getSignedInUser();
    updateODStatus();
    await od.initRootStructure();
    await loadAllCases();
    await loadSkills();
    toast(`Connecté : ${oneDriveUser}`, 'success');
  } catch (err) { toast('Erreur connexion OneDrive : ' + (err as Error).message, 'error'); }
}

async function refreshCaseFromOneDrive(): Promise<void> {
  if (!activeCase) return;
  if (!oneDriveUser) { await connectOneDrive(); return; }

  try {
    const items = await od.listCaseFiles(activeCase.folderName);
    let added = 0;

    for (const item of items) {
      if (!item.file) continue;
      if (!isSupported(item.name)) continue;
      const exists = activeCase.documents.some(d => d.name === item.name);
      if (exists) continue;

      activeCase.documents.push({
        name:      item.name,
        kind:      guessKind(item.name),
        mimeType:  item.file.mimeType || 'application/octet-stream',
        sizeBytes: item.size ?? 0,
        addedAt:   Date.now(),
      });
      added++;
    }

    if (added > 0) {
      await saveMeta();
      renderDocList();
      updateDocCount();
    }
    toast(`${added} nouveau(x) document(s) indexé(s) depuis OneDrive.`, 'success');
  } catch (err) { toast('Erreur sync : ' + (err as Error).message, 'error'); }
}

// ─── Empty / not-connected states ─────────────────────────────────────────────

function showEmptyState(): void {
  const chat = qs<HTMLElement>('#chat-area');
  chat.innerHTML = '';
  chat.appendChild(el('div', { className: 'empty-state' },
    el('div', { className: 'empty-icon', textContent: '⚖️' }),
    el('h2', { textContent: 'Bienvenue dans Lex Assistant' }),
    el('p', { textContent: 'Connectez OneDrive et créez votre premier dossier.' }),
    (() => { const b = el('button', { className: 'btn btn--primary', textContent: '+ Nouveau dossier' }); b.onclick = () => openCaseFormModal(null); return b; })()
  ));
}

function showNotConnected(): void {
  const chat = qs<HTMLElement>('#chat-area');
  chat.innerHTML = '';
  chat.appendChild(el('div', { className: 'empty-state' },
    el('div', { className: 'empty-icon', textContent: '☁' }),
    el('h2', { textContent: 'OneDrive non connecté' }),
    el('p', { textContent: 'Configurez votre App Registration Azure et connectez-vous pour accéder à vos dossiers.' }),
    (() => { const b = el('button', { className: 'btn btn--primary', textContent: '☁ Configurer OneDrive' }); b.onclick = () => openSettingsModal(); return b; })()
  ));
}

// ─── Case list ────────────────────────────────────────────────────────────────

function renderCaseList(): void {
  const list = qs<HTMLElement>('#case-list');
  list.innerHTML = '';
  for (const c of cases) {
    const item = el('div', { className: 'case-item' + (c.folderName === activeCase?.folderName ? ' active' : '') });
    item.dataset.folder = c.folderName;
    const statusLabels = { active: 'En cours', closed: 'Clôturé', suspended: 'Suspendu' };
    item.append(
      el('span', { className: 'case-item__name', textContent: c.name }),
      el('span', { className: 'case-item__domain', textContent: c.domain }),
      el('span', { className: `case-item__status case-item__status--${c.status}`, textContent: statusLabels[c.status] })
    );
    item.onclick = () => selectCase(c.folderName);
    item.addEventListener('contextmenu', (e) => { e.preventDefault(); openCaseContextMenu(c, e.clientX, e.clientY); });
    list.appendChild(item);
  }
}

// ─── Case modal ───────────────────────────────────────────────────────────────

function sanitiseFolder(name: string): string {
  return name.replace(/[/\\:*?"<>|]/g, '_').replace(/\s+/g, '_').slice(0, 60);
}

function openCaseFormModal(existing: LexCase | null): void {
  if (!oneDriveUser) { openSettingsModal(); toast('Connectez OneDrive d\'abord.', 'error'); return; }
  const isEdit = !!existing;
  const overlay = el('div', { className: 'modal-overlay' });
  const dialog  = el('div', { className: 'modal-dialog modal-dialog--form' });
  dialog.innerHTML = `
    <h2 class="modal-title">${isEdit ? 'Modifier le dossier' : 'Nouveau dossier'}</h2>
    <label class="form-label">Intitulé du dossier <span class="required">*</span></label>
    <input class="form-input" id="f-name" type="text" placeholder="Ex. : DUPONT — Cession de fonds de commerce" value="${existing?.name ?? ''}"/>
    <label class="form-label">Domaine juridique</label>
    <input class="form-input" id="f-domain" type="text" placeholder="Ex. : Droit commercial" value="${existing?.domain ?? ''}"/>
    <label class="form-label">Nom du dossier OneDrive <span style="font-weight:400;color:var(--c-gray-400)">(auto-généré si vide)</span></label>
    <input class="form-input" id="f-folder" type="text" placeholder="Ex. : DUPONT_Cession" value="${existing?.folderName ?? ''}"/>
    <label class="form-label">Statut</label>
    <select class="form-select" id="f-status">
      <option value="active" ${!existing||existing.status==='active'?'selected':''}>En cours</option>
      <option value="suspended" ${existing?.status==='suspended'?'selected':''}>Suspendu</option>
      <option value="closed" ${existing?.status==='closed'?'selected':''}>Clôturé</option>
    </select>
    <div class="modal-btns">
      <button class="btn btn--secondary" id="f-cancel">Annuler</button>
      <button class="btn btn--primary" id="f-save">${isEdit ? 'Enregistrer' : 'Créer'}</button>
    </div>`;
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);

  // Auto-fill folder name from case name
  const nameInput   = qs<HTMLInputElement>('#f-name', dialog);
  const folderInput = qs<HTMLInputElement>('#f-folder', dialog);
  nameInput.addEventListener('input', () => {
    if (!isEdit && !folderInput.value) folderInput.placeholder = sanitiseFolder(nameInput.value) || 'DOSSIER_NOM';
  });

  qs<HTMLButtonElement>('#f-cancel', dialog).onclick = () => overlay.remove();
  qs<HTMLButtonElement>('#f-save', dialog).onclick = async () => {
    const name      = nameInput.value.trim();
    const domain    = qs<HTMLInputElement>('#f-domain', dialog).value.trim() || 'Droit général';
    const rawFolder = folderInput.value.trim();
    const folder    = rawFolder ? sanitiseFolder(rawFolder) : sanitiseFolder(name);
    const status    = qs<HTMLSelectElement>('#f-status', dialog).value as LexCase['status'];
    if (!name) { toast('Le nom est obligatoire.', 'error'); return; }
    if (!folder) { toast('Nom de dossier invalide.', 'error'); return; }

    const btn = qs<HTMLButtonElement>('#f-save', dialog);
    btn.disabled = true; btn.textContent = 'Création…';

    const now = Date.now();
    const meta: CaseMeta = {
      name, folderName: folder, domain, status,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now, documents: existing?.documents ?? []
    };

    try {
      await od.writeCaseMeta(folder, meta);
      overlay.remove();

      const c: LexCase = { ...meta, documents: meta.documents };
      if (isEdit) {
        const idx = cases.findIndex(x => x.folderName === existing!.folderName);
        if (idx >= 0) cases[idx] = c;
        if (activeCase?.folderName === existing!.folderName) activeCase = c;
      } else {
        cases.unshift(c);
      }
      renderCaseList();
      await selectCase(folder);
      toast(isEdit ? 'Dossier modifié.' : 'Dossier créé.', 'success');
    } catch (err) {
      toast('Erreur : ' + (err as Error).message, 'error');
      btn.disabled = false; btn.textContent = isEdit ? 'Enregistrer' : 'Créer';
    }
  };
  nameInput.focus();
}

function openCaseContextMenu(c: LexCase, x: number, y: number): void {
  document.getElementById('context-menu')?.remove();
  const menu = el('div', { className: 'context-menu', id: 'context-menu' });
  menu.style.left = `${x}px`; menu.style.top = `${y}px`;
  const items = [
    { label: 'Modifier',           action: () => openCaseFormModal(c) },
    { label: '☁ Sync OneDrive',    action: () => refreshCaseFromOneDrive() },
    { label: 'Effacer conversation',action: () => clearConversation(c.folderName) },
    { label: 'Supprimer le dossier',action: () => deleteCase(c.folderName), danger: true },
  ];
  for (const item of items) {
    const btn = el('button', { className: 'context-menu__item' + (item.danger ? ' context-menu__item--danger' : ''), textContent: item.label });
    btn.onclick = () => { menu.remove(); item.action(); };
    menu.appendChild(btn);
  }
  document.body.appendChild(menu);
  const dismiss = (e: MouseEvent) => { if (!menu.contains(e.target as Node)) { menu.remove(); document.removeEventListener('click', dismiss); } };
  setTimeout(() => document.addEventListener('click', dismiss), 0);
}

async function clearConversation(folderName: string): Promise<void> {
  const ok = await confirm('Effacer tout l\'historique de conversation de ce dossier ?');
  if (!ok) return;
  caseMessages = [];
  await od.writeConversation(folderName, []);
  if (activeCase?.folderName === folderName) renderChat();
  toast('Conversation effacée.', 'info');
}

async function deleteCase(folderName: string): Promise<void> {
  const ok = await confirm('Supprimer ce dossier ? Les fichiers OneDrive sont conservés — seules les métadonnées Lex Assistant sont supprimées.');
  if (!ok) return;
  // Delete _meta, _notes, _conversation only — preserve user files
  try {
    await od.deleteFilePath(`${od.casePath(folderName)}/_meta.json`);
    await od.deleteFilePath(`${od.casePath(folderName)}/_notes.json`).catch(() => {});
    await od.deleteFilePath(`${od.casePath(folderName)}/_conversation.json`).catch(() => {});
  } catch {}
  cases = cases.filter(c => c.folderName !== folderName);
  renderCaseList();
  if (activeCase?.folderName === folderName) {
    activeCase = null;
    if (cases.length > 0) await selectCase(cases[0].folderName);
    else showEmptyState();
  }
  toast('Dossier supprimé.', 'success');
}

// ─── Document list ────────────────────────────────────────────────────────────

let docFilter: 'all' | 'piece' | 'jurisprudence' | 'doctrine' | 'redige' = 'all';

function renderDocList(): void {
  const list = qs<HTMLElement>('#doc-list');
  list.innerHTML = '';
  if (!activeCase) return;

  const docs = docFilter === 'all'
    ? activeCase.documents
    : activeCase.documents.filter(d => d.kind === docFilter);

  if (docs.length === 0) {
    list.appendChild(el('div', { className: 'doc-empty', textContent: 'Aucun document. Uploadez ou synchronisez OneDrive.' }));
    return;
  }

  for (const doc of [...docs].sort((a,b) => b.addedAt - a.addedAt)) {
    const item = el('div', { className: 'doc-item' });
    const info = el('div', { className: 'doc-info' });
    info.append(
      el('div', { className: 'doc-name', textContent: doc.name }),
      el('div', { className: 'doc-meta', textContent: `${formatDate(doc.addedAt)} · ${mimeLabel(doc.mimeType)} · ${formatSize(doc.sizeBytes)}` })
    );
    const del = el('button', { className: 'doc-delete', textContent: '×', title: 'Retirer du dossier' });
    del.onclick = async (e) => {
      e.stopPropagation();
      const ok = await confirm(`Retirer "${doc.name}" du dossier ?\n(Le fichier OneDrive est conservé, seul l'index local est supprimé.)`);
      if (!ok) return;
      activeCase!.documents = activeCase!.documents.filter(d => d.name !== doc.name);
      await saveMeta();
      renderDocList();
      updateDocCount();
      toast('Document retiré de l\'index.', 'info');
    };
    item.append(
      el('span', { className: 'doc-icon', textContent: mimeIcon(doc.mimeType) }),
      info,
      el('span', { className: `doc-kind doc-kind--${doc.kind}`, textContent: kindLabel(doc.kind) }),
      del
    );
    list.appendChild(item);
  }
}

function updateDocCount(): void {
  const el = document.getElementById('doc-count');
  if (el && activeCase) el.textContent = `${activeCase.documents.length} pièce${activeCase.documents.length !== 1 ? 's' : ''}`;
}

// ─── Note bar ─────────────────────────────────────────────────────────────────

function renderNoteBar(): void {
  const bar = qs<HTMLElement>('#note-bar');
  bar.innerHTML = '';
  toggle(bar, caseNotes.length > 0);
  if (!caseNotes.length) return;
  const n = caseNotes.length;
  bar.append(
    el('span', { className: 'note-badge', textContent: String(n) }),
    el('span', { className: 'note-bar__text', textContent: `note${n>1?'s':''} active${n>1?'s':''} · ` + caseNotes.map(x => x.content.slice(0,40)+'…').join(' — ') }),
    (() => { const b = el('button', { className: 'note-bar__manage', textContent: 'Gérer' }); b.onclick = () => openNotesModal(); return b; })()
  );
}

// ─── Notes modal ──────────────────────────────────────────────────────────────

function openNotesModal(): void {
  const overlay = el('div', { className: 'modal-overlay' });
  const dialog  = el('div', { className: 'modal-dialog modal-dialog--notes' });

  const refresh = () => {
    const list = qs<HTMLElement>('#notes-list', dialog);
    list.innerHTML = '';
    if (!caseNotes.length) {
      list.appendChild(el('p', { className: 'note-empty', textContent: 'Aucune note. Rédigez des corrections en mode "Note permanente" ou ajoutez-en une ci-dessous.' }));
      return;
    }
    for (const note of [...caseNotes].sort((a,b) => b.createdAt - a.createdAt)) {
      const row = el('div', { className: 'note-row' });
      const del = el('button', { className: 'btn btn--sm btn--danger', textContent: 'Supprimer' });
      del.onclick = async () => {
        caseNotes = caseNotes.filter(n => n.id !== note.id);
        await saveNotes();
        renderNoteBar();
        refresh();
      };
      row.append(
        el('p', { className: 'note-content', textContent: note.content }),
        el('span', { className: 'note-meta', textContent: formatDateTime(note.createdAt) }),
        del
      );
      list.appendChild(row);
    }
  };

  dialog.innerHTML = `
    <h2 class="modal-title">Notes permanentes du dossier</h2>
    <p class="modal-subtitle">Sauvegardées dans <code>_notes.json</code> du dossier OneDrive. Réinjectées dans chaque appel Claude (priorité absolue).</p>
    <div id="notes-list"></div><hr>
    <label class="form-label">Ajouter une correction ou précision</label>
    <textarea class="form-textarea" id="new-note" rows="3" placeholder="Ex. : Les pénalités CGI art.1727 provisionnées par LEGATIS ne sont pas justifiées — contester systématiquement."></textarea>
    <div class="modal-btns">
      <button class="btn btn--secondary" id="n-close">Fermer</button>
      <button class="btn btn--primary" id="n-add">Ajouter</button>
    </div>`;
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);
  refresh();

  qs<HTMLButtonElement>('#n-close', dialog).onclick = () => overlay.remove();
  qs<HTMLButtonElement>('#n-add', dialog).onclick = async () => {
    const val = qs<HTMLTextAreaElement>('#new-note', dialog).value.trim();
    if (!val) return;
    const note: PermanentNote = { id: uid(), content: val, createdAt: Date.now(), updatedAt: Date.now() };
    caseNotes.push(note);
    await saveNotes();
    renderNoteBar();
    refresh();
    qs<HTMLTextAreaElement>('#new-note', dialog).value = '';
    toast('Note sauvegardée dans _notes.json.', 'success');
  };
}

// ─── Chat ─────────────────────────────────────────────────────────────────────

function renderChat(): void {
  const area = qs<HTMLElement>('#chat-area');
  area.innerHTML = '';
  if (!caseMessages.length) {
    const c = activeCase;
    if (!c) return;
    area.appendChild(el('div', { className: 'msg msg--assistant' },
      el('div', { className: 'msg__label', textContent: 'Lex Assistant' }),
      el('div', { className: 'msg__bubble' },
        el('p', { innerHTML: `Dossier <strong>${c.name}</strong>. ${c.documents.length} pièce(s), ${caseNotes.length} note(s)${skills.length ? `, ${skills.length} skill(s)` : ''}.` }),
        el('p', { textContent: 'Que souhaitez-vous faire ?' })
      )
    ));
    return;
  }
  for (const msg of caseMessages) area.appendChild(buildMsgEl(msg));
  area.scrollTop = area.scrollHeight;
}

function buildMsgEl(msg: ChatMessage): HTMLElement {
  const wrap   = el('div', { className: `msg msg--${msg.role}` });
  const bubble = el('div', { className: 'msg__bubble' });
  bubble.innerHTML = renderMarkdown(msg.content);
  wrap.append(el('div', { className: 'msg__label', textContent: msg.role === 'user' ? 'Vous' : 'Lex Assistant' }), bubble);

  if (msg.role === 'assistant') {
    const actions = el('div', { className: 'msg__actions' });

    const copy = el('button', { className: 'msg-action-btn', textContent: 'Copier' });
    copy.onclick = () => { navigator.clipboard.writeText(msg.content); toast('Copié.', 'info', 1500); };
    actions.appendChild(copy);

    if (msg.mode === 'redaction' || msg.generatedDocName) {
      // Download DOCX
      const dl = el('button', { className: 'msg-action-btn msg-action-btn--primary', textContent: '⬇ Télécharger .docx' });
      dl.onclick = async () => {
        try {
          const blob = await generateDocx({ title: msg.generatedDocName ?? 'Document', content: msg.content, caseRef: activeCase?.name ?? '' });
          downloadBlob(blob, (msg.generatedDocName ?? 'document').replace(/[^a-z0-9_\- ]/gi,'_') + '.docx');
        } catch (err) { toast('Erreur DOCX : ' + (err as Error).message, 'error'); }
      };
      actions.appendChild(dl);

      // Save to OneDrive case folder
      const odSave = el('button', { className: 'msg-action-btn', textContent: '☁ Sauver sur OneDrive' });
      odSave.onclick = async () => {
        if (!activeCase) return;
        try {
          const blob = await generateDocx({ title: msg.generatedDocName ?? 'Document', content: msg.content, caseRef: activeCase.name });
          const ab   = await blob.arrayBuffer();
          const fname = (msg.generatedDocName ?? 'document').replace(/[^a-z0-9_\- ]/gi,'_') + '.docx';
          const mime  = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
          await od.writeCaseFile(activeCase.folderName, fname, ab, mime);

          // Register in meta
          const already = activeCase.documents.some(d => d.name === fname);
          if (!already) {
            activeCase.documents.push({ name: fname, kind: 'redige', mimeType: mime, sizeBytes: ab.byteLength, addedAt: Date.now() });
            await saveMeta();
            renderDocList(); updateDocCount();
          }
          toast(`"${fname}" sauvegardé dans ${activeCase.folderName}/.`, 'success');
        } catch (err) { toast('Erreur OneDrive : ' + (err as Error).message, 'error'); }
      };
      actions.appendChild(odSave);
    }
    wrap.appendChild(actions);
  }
  return wrap;
}

function appendMsg(msg: ChatMessage): void {
  const area = qs<HTMLElement>('#chat-area');
  area.querySelector('.empty-state')?.remove();
  area.appendChild(buildMsgEl(msg));
  area.scrollTop = area.scrollHeight;
}

function appendTyping(): HTMLElement {
  const area   = qs<HTMLElement>('#chat-area');
  const typing = el('div', { className: 'msg msg--assistant', id: 'typing' });
  const bubble = el('div', { className: 'msg__bubble' });
  bubble.append(spinnerEl(), el('span', { textContent: ' Analyse en cours…' }));
  typing.append(el('div', { className: 'msg__label', textContent: 'Lex Assistant' }), bubble);
  area.appendChild(typing);
  area.scrollTop = area.scrollHeight;
  return typing;
}

// ─── Send ─────────────────────────────────────────────────────────────────────

async function sendMessage(): Promise<void> {
  const ta  = qs<HTMLTextAreaElement>('#user-input');
  const text = ta.value.trim();
  if (!text || !activeCase) return;
  if (!getStoredKey()) { openSettingsModal(); toast('Configurez votre clé API Claude.', 'error'); return; }
  if (!oneDriveUser)   { await connectOneDrive(); return; }

  ta.value = '';
  autoResize(ta);

  const userMsg: ChatMessage = { id: uid(), role: 'user', content: text, timestamp: Date.now(), mode: activeMode };
  caseMessages.push(userMsg);
  appendMsg(userMsg);

  // Note mode — also save as permanent note
  if (activeMode === 'note') {
    const note: PermanentNote = { id: uid(), content: text, createdAt: Date.now(), updatedAt: Date.now() };
    caseNotes.push(note);
    await saveNotes();
    renderNoteBar();
  }

  const typing  = appendTyping();
  const sendBtn = qs<HTMLButtonElement>('#send-btn');
  sendBtn.disabled = true;

  try {
    const response = await callClaudeCase({
      caseName:   activeCase.name,
      caseDomain: activeCase.domain,
      folderName: activeCase.folderName,
      notes:      caseNotes,
      docs:       activeCase.documents,
      skills,
      mode:       activeMode,
      userMessage:text,
    });

    typing.remove();

    let docName: string | undefined;
    if (activeMode === 'redaction') {
      const first = response.split('\n')[0].replace(/^#+\s*/,'').trim();
      docName = first.length > 0 && first.length < 100 ? first : 'Document rédigé';
    }

    const asst: ChatMessage = { id: uid(), role: 'assistant', content: response, timestamp: Date.now(), mode: activeMode, generatedDocName: docName };
    caseMessages.push(asst);
    appendMsg(asst);

    // Persist conversation to OneDrive
    await saveConversation();

  } catch (err) {
    typing.remove();
    toast((err as Error).message, 'error', 6000);
    caseMessages.pop(); // remove user msg if failed
  } finally {
    sendBtn.disabled = false;
    ta.focus();
  }
}

// ─── Topbar ───────────────────────────────────────────────────────────────────

function setupTopbar(): void {
  qs<HTMLButtonElement>('#btn-new-case-top').onclick = () => openCaseFormModal(null);
  qs<HTMLButtonElement>('#btn-settings').onclick     = () => openSettingsModal();
  qs<HTMLButtonElement>('#btn-onedrive').onclick     = async () => {
    if (!oneDriveUser) await connectOneDrive();
    else await refreshCaseFromOneDrive();
  };
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function setupSidebar(): void {
  qs<HTMLButtonElement>('#btn-new-case-sidebar').onclick = () => openCaseFormModal(null);
  qs<HTMLButtonElement>('#btn-notes-open').onclick       = () => openNotesModal();
  qs<HTMLButtonElement>('#btn-od-sync').onclick          = () => refreshCaseFromOneDrive();

  const tabs = qsa<HTMLButtonElement>('.doc-filter-tab');
  for (const tab of tabs) {
    tab.onclick = () => {
      setActive(tabs, tab, 'active');
      docFilter = (tab.dataset.filter ?? 'all') as typeof docFilter;
      renderDocList();
    };
  }

  const fileInput = qs<HTMLInputElement>('#file-input');
  qs<HTMLButtonElement>('#btn-upload').onclick = () => fileInput.click();
  fileInput.onchange = async () => {
    if (!activeCase || !fileInput.files?.length) return;
    if (!oneDriveUser) { await connectOneDrive(); return; }

    for (const file of Array.from(fileInput.files)) {
      try {
        const ab   = await file.arrayBuffer();
        const meta = makeCaseDocMeta(file);

        // Upload to OneDrive case folder
        await od.writeCaseFile(activeCase.folderName, file.name, ab, meta.mimeType);

        // Register in meta if not already present
        const already = activeCase.documents.some(d => d.name === file.name);
        if (!already) activeCase.documents.push(meta);

        toast(`"${file.name}" uploadé sur OneDrive.`, 'success', 2000);
      } catch (err) { toast(`Erreur : ${(err as Error).message}`, 'error'); }
    }

    fileInput.value = '';
    await saveMeta();
    renderDocList();
    updateDocCount();
  };
}

// ─── Mode bar ─────────────────────────────────────────────────────────────────

function setupModeBar(): void {
  const btns = qsa<HTMLButtonElement>('.mode-btn[data-mode]');
  for (const btn of btns) {
    btn.onclick = () => {
      setActive(btns, btn, 'active');
      activeMode = btn.dataset.mode as WorkMode;
      const hints: Record<WorkMode, string> = {
        analyse:     'Posez une question, demandez une analyse du dossier…',
        redaction:   'Précisez l\'acte à rédiger (courrier, assignation, conclusions, contrat…)',
        modification:'Indiquez le document à modifier et les changements souhaités…',
        note:        'Rédigez une correction ou précision → sauvegardée dans _notes.json…'
      };
      qs<HTMLTextAreaElement>('#user-input').placeholder = hints[activeMode];
    };
  }
  qs<HTMLButtonElement>('#btn-case-summary').onclick = async () => {
    qs<HTMLTextAreaElement>('#user-input').value = 'Fais un point complet sur ce dossier : enjeux principaux, risques identifiés, actions restantes, points d\'attention prioritaires.';
    await sendMessage();
  };
}

// ─── Input ────────────────────────────────────────────────────────────────────

function autoResize(ta: HTMLTextAreaElement): void {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
}

function setupInputArea(): void {
  const ta = qs<HTMLTextAreaElement>('#user-input');
  ta.addEventListener('input', () => autoResize(ta));
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
  qs<HTMLButtonElement>('#send-btn').onclick = () => sendMessage();
  qsa<HTMLButtonElement>('.quick-btn').forEach(b => { b.onclick = () => { ta.value = b.dataset.prompt ?? ''; autoResize(ta); ta.focus(); }; });
}

// ─── Settings modal ───────────────────────────────────────────────────────────

function openSettingsModal(): void {
  document.getElementById('settings-overlay')?.remove();
  const overlay = el('div', { className: 'modal-overlay', id: 'settings-overlay' });
  const dialog  = el('div', { className: 'modal-dialog modal-dialog--settings' });
  const cfg     = od.getConfig();

  dialog.innerHTML = `
    <h2 class="modal-title">⚙ Paramètres</h2>

    <h3 class="settings-section-title">Clé API Claude (Anthropic)</h3>
    <p class="settings-hint">Stockée dans localStorage. Transmise uniquement à api.anthropic.com.</p>
    <input class="form-input" id="s-api" type="password" placeholder="sk-ant-api03-…" value="${getStoredKey()}" autocomplete="off"/>
    <div style="display:flex;gap:8px;margin-top:6px">
      <button class="btn btn--primary btn--sm" id="s-api-save">Enregistrer</button>
      <button class="btn btn--secondary btn--sm" id="s-api-clear">Effacer</button>
    </div>

    <hr style="margin:20px 0">

    <h3 class="settings-section-title">☁ Microsoft OneDrive (Graph API)</h3>
    <p class="settings-hint">
      <strong>portal.azure.com</strong> → App registrations → New registration<br>
      Type : <em>Single-page application (SPA)</em><br>
      Redirect URI : <code>${window.location.origin}</code><br>
      Permissions : <code>Files.ReadWrite</code> + <code>User.Read</code>
    </p>
    <label class="form-label">Application (Client) ID <span class="required">*</span></label>
    <input class="form-input" id="s-client" type="text" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="${cfg?.clientId ?? ''}"/>
    <label class="form-label">Tenant ID</label>
    <input class="form-input" id="s-tenant" type="text" placeholder="common" value="${cfg?.tenantId ?? 'common'}"/>
    <label class="form-label">Dossier racine OneDrive</label>
    <input class="form-input" id="s-root" type="text" placeholder="LexAssistant" value="${cfg?.rootFolder ?? 'LexAssistant'}"/>
    <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
      <button class="btn btn--primary btn--sm" id="s-od-save">Enregistrer</button>
      <button class="btn btn--secondary btn--sm" id="s-od-init">Initialiser structure OneDrive</button>
      <button class="btn btn--secondary btn--sm" id="s-od-signout">Déconnecter</button>
    </div>
    ${oneDriveUser ? `<p class="od-connected-label">✓ Connecté : ${oneDriveUser}</p>` : ''}

    <div class="modal-btns" style="margin-top:24px">
      <button class="btn btn--secondary" id="s-close">Fermer</button>
    </div>`;

  overlay.appendChild(dialog);
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  qs<HTMLButtonElement>('#s-close', dialog).onclick    = () => overlay.remove();
  qs<HTMLButtonElement>('#s-api-save', dialog).onclick = () => {
    const v = qs<HTMLInputElement>('#s-api', dialog).value.trim();
    if (!v) { toast('Clé vide.', 'error'); return; }
    setStoredKey(v); toast('Clé API enregistrée.', 'success');
  };
  qs<HTMLButtonElement>('#s-api-clear', dialog).onclick = () => {
    clearStoredKey(); qs<HTMLInputElement>('#s-api', dialog).value = '';
    toast('Clé effacée.', 'info');
  };
  qs<HTMLButtonElement>('#s-od-save', dialog).onclick = () => {
    const clientId  = qs<HTMLInputElement>('#s-client', dialog).value.trim();
    const tenantId  = qs<HTMLInputElement>('#s-tenant', dialog).value.trim() || 'common';
    const rootFolder = qs<HTMLInputElement>('#s-root', dialog).value.trim() || 'LexAssistant';
    if (!clientId) { toast('Client ID requis.', 'error'); return; }
    od.setConfig({ clientId, tenantId, rootFolder });
    toast('Configuration OneDrive enregistrée.', 'success');
  };
  qs<HTMLButtonElement>('#s-od-init', dialog).onclick = async () => {
    if (!od.isConfigured()) { toast('Sauvegardez la configuration d\'abord.', 'error'); return; }
    try {
      if (!oneDriveUser) { await od.signIn(); oneDriveUser = od.getSignedInUser(); updateODStatus(); }
      await od.initRootStructure();
      toast('Structure initialisée avec succès.', 'success');
    } catch (err) { toast('Erreur : ' + (err as Error).message, 'error'); }
  };
  qs<HTMLButtonElement>('#s-od-signout', dialog).onclick = async () => {
    await od.signOut(); oneDriveUser = null; updateODStatus();
    toast('Déconnecté.', 'info'); overlay.remove();
  };
}

document.addEventListener('DOMContentLoaded', boot);
