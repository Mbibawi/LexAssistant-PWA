/**
 * onedrive.ts — Microsoft Graph API, path-based, no item IDs.
 *
 * All Graph calls use the /me/drive/root:/<path>: pattern.
 * No IndexedDB. State lives in JSON files on OneDrive:
 *
 *   LexAssistant/
 *     _Skills/                 ← .md/.txt — injected into every prompt
 *     Affaires/
 *       <FolderName>/
 *         _meta.json           ← CaseMeta (name, domain, status, document registry)
 *         _notes.json          ← PermanentNote[] (user corrections)
 *         _conversation.json   ← ChatMessage[] (conversation history)
 *         <file.pdf>           ← actual documents
 *     Bibliotheque/
 *       <Domain>/
 *         _meta.json           ← LibDomainMeta
 *         _conversation.json   ← LibConversationMessage[]
 *         <file.pdf>
 */

import type {
  GraphDriveItem, OneDriveConfig,
  CaseMeta, NotesFile, ConversationFile, ChatMessage,
  PermanentNote, LibDomainMeta, LibConversationMessage
} from '../types.js';

// ─── Config (localStorage only — not a document) ─────────────────────────────

const LS_CONFIG = 'lex_onedrive_config';
const MSAL_CDN  = 'https://cdn.jsdelivr.net/npm/@azure/msal-browser@3/dist/index.iife.min.js';
const GRAPH     = 'https://graph.microsoft.com/v1.0';
const SCOPES    = ['Files.ReadWrite', 'User.Read'];

export function getConfig(): OneDriveConfig | null {
  const raw = localStorage.getItem(LS_CONFIG);
  try { return raw ? JSON.parse(raw) as OneDriveConfig : null; }
  catch { return null; }
}
export function setConfig(cfg: OneDriveConfig): void {
  localStorage.setItem(LS_CONFIG, JSON.stringify(cfg));
}
export function clearConfig(): void { localStorage.removeItem(LS_CONFIG); }
export function isConfigured(): boolean {
  const c = getConfig(); return Boolean(c?.clientId && c?.rootFolder);
}
export function root(): string { return getConfig()?.rootFolder ?? 'LexAssistant'; }

// ─── MSAL ─────────────────────────────────────────────────────────────────────

interface MsalApp {
  loginPopup(r: { scopes: string[] }): Promise<{ accessToken: string }>;
  acquireTokenSilent(r: { scopes: string[]; account: MsalAccount }): Promise<{ accessToken: string }>;
  acquireTokenPopup(r: { scopes: string[] }): Promise<{ accessToken: string }>;
  getAllAccounts(): MsalAccount[];
  handleRedirectPromise(): Promise<null>;
}
interface MsalAccount { homeAccountId: string; username: string; name?: string }
declare global { interface Window { msal: { PublicClientApplication: new (c: object) => MsalApp } } }

let _app: MsalApp | null = null;
let _loading: Promise<MsalApp> | null = null;
let _account: MsalAccount | null = null;

function getMsal(): Promise<MsalApp> {
  if (_app) return Promise.resolve(_app);
  if (_loading) return _loading;
  _loading = new Promise((res, rej) => {
    const init = async () => {
      const cfg = getConfig();
      if (!cfg) throw new Error('OneDrive non configuré');
      const app = new window.msal.PublicClientApplication({
        auth: { clientId: cfg.clientId, authority: `https://login.microsoftonline.com/${cfg.tenantId ?? 'common'}`, redirectUri: window.location.origin },
        cache: { cacheLocation: 'sessionStorage', storeAuthStateInCookie: false }
      });
      await app.handleRedirectPromise().catch(() => null);
      _app = app;
      return app;
    };
    if (window.msal) { init().then(res).catch(rej); return; }
    const s = document.createElement('script');
    s.src = MSAL_CDN;
    s.onload = () => init().then(res).catch(rej);
    s.onerror = () => rej(new Error('Impossible de charger MSAL'));
    document.head.appendChild(s);
  });
  return _loading;
}

export async function getAccessToken(): Promise<string> {
  const app = await getMsal();
  if (!_account) { const a = app.getAllAccounts(); if (a.length) _account = a[0]; }
  if (_account) {
    try { return (await app.acquireTokenSilent({ scopes: SCOPES, account: _account })).accessToken; }
    catch { /* fall through to popup */ }
  }
  const r = await app.loginPopup({ scopes: SCOPES });
  _account = app.getAllAccounts()[0] ?? null;
  return r.accessToken;
}

export async function signIn(): Promise<void> {
  const app = await getMsal();
  await app.loginPopup({ scopes: SCOPES });
  _account = app.getAllAccounts()[0] ?? null;
}

export async function signOut(): Promise<void> {
  _account = null; _app = null; _loading = null;
  sessionStorage.clear();
}

export async function isSignedIn(): Promise<boolean> {
  try {
    const app = await getMsal();
    const accounts = app.getAllAccounts();
    if (accounts.length) { _account = accounts[0]; return true; }
    return false;
  } catch { return false; }
}

export function getSignedInUser(): string | null {
  return _account?.name ?? _account?.username ?? null;
}

// ─── Graph HTTP helpers ───────────────────────────────────────────────────────

// Encode a OneDrive path for use in a Graph URL
// "LexAssistant/Affaires/DUPONT" → "/me/drive/root:/LexAssistant/Affaires/DUPONT:"
function p(odPath: string): string {
  const encoded = odPath.split('/').map(seg => encodeURIComponent(seg)).join('/');
  return `/me/drive/root:/${encoded}:`;
}

async function gFetch(path: string, opts: RequestInit = {}, rawBody = false): Promise<Response> {
  const token = await getAccessToken();
  const headers: HeadersInit = { Authorization: `Bearer ${token}`, ...(opts.headers ?? {}) };
  if (!rawBody && opts.body && typeof opts.body === 'string') {
    (headers as Record<string,string>)['Content-Type'] = 'application/json';
  }
  const resp = await fetch(`${GRAPH}${path}`, { ...opts, headers });
  if (!resp.ok) {
    let msg = resp.statusText;
    try { const e = await resp.json() as { error?: { message?: string } }; msg = e.error?.message ?? msg; } catch {}
    throw new Error(`Graph ${resp.status}: ${msg}`);
  }
  return resp;
}

// ─── Folder operations ────────────────────────────────────────────────────────

export async function ensureFolder(folderPath: string): Promise<void> {
  // Try GET; if not found, create via parent
  try { await gFetch(p(folderPath)); return; } catch {}
  const parts = folderPath.split('/');
  const name  = parts.pop()!;
  const parentPath = parts.join('/');
  const parentEndpoint = parentPath
    ? `${p(parentPath)}/children`
    : `/me/drive/root/children`;
  await gFetch(parentEndpoint, {
    method: 'POST',
    body: JSON.stringify({ name, folder: {}, '@microsoft.graph.conflictBehavior': 'rename' })
  });
}

export async function listFolder(folderPath: string): Promise<GraphDriveItem[]> {
  const resp = await gFetch(`${p(folderPath)}/children?$select=name,size,file,folder,webUrl,lastModifiedDateTime&$top=500`);
  const data = await resp.json() as { value: GraphDriveItem[] };
  return data.value ?? [];
}

// ─── File read/write by PATH ──────────────────────────────────────────────────

export async function readFilePath(filePath: string): Promise<ArrayBuffer> {
  const token = await getAccessToken();
  const resp = await fetch(`${GRAPH}${p(filePath)}/content`, { headers: { Authorization: `Bearer ${token}` } });
  if (!resp.ok) throw new Error(`Read ${filePath}: ${resp.status}`);
  return resp.arrayBuffer();
}

export async function writeFilePath(filePath: string, data: ArrayBuffer | string, mimeType: string): Promise<void> {
  const token = await getAccessToken();
  const body  = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  const resp  = await fetch(`${GRAPH}${p(filePath)}/content`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': mimeType },
    body
  });
  if (!resp.ok) {
    let msg = resp.statusText;
    try { const e = await resp.json() as { error?: { message?: string } }; msg = e.error?.message ?? msg; } catch {}
    throw new Error(`Write ${filePath}: ${msg}`);
  }
}

// Large file — resumable upload session
export async function writeFileLarge(filePath: string, data: ArrayBuffer, mimeType: string): Promise<void> {
  if (data.byteLength <= 4 * 1024 * 1024) { await writeFilePath(filePath, data, mimeType); return; }
  const sessResp = await gFetch(`${p(filePath)}/createUploadSession`, {
    method: 'POST',
    body: JSON.stringify({ item: { '@microsoft.graph.conflictBehavior': 'replace' } })
  });
  const { uploadUrl } = await sessResp.json() as { uploadUrl: string };
  const chunk = 10 * 1024 * 1024;
  for (let off = 0; off < data.byteLength; off += chunk) {
    const end = Math.min(off + chunk, data.byteLength);
    const r = await fetch(uploadUrl, {
      method: 'PUT',
      headers: { 'Content-Range': `bytes ${off}-${end-1}/${data.byteLength}` },
      body: data.slice(off, end)
    });
    if (!r.ok && r.status !== 202) throw new Error(`Chunk upload failed at ${off}`);
  }
}

export async function deleteFilePath(filePath: string): Promise<void> {
  await gFetch(`${p(filePath)}`, { method: 'DELETE' });
}

export async function fileExists(filePath: string): Promise<boolean> {
  try { await gFetch(p(filePath)); return true; } catch { return false; }
}

// ─── JSON helpers ─────────────────────────────────────────────────────────────

async function readJson<T>(filePath: string): Promise<T | null> {
  try {
    const buf = await readFilePath(filePath);
    const text = new TextDecoder().decode(buf);
    return JSON.parse(text) as T;
  } catch { return null; }
}

async function writeJson(filePath: string, data: unknown): Promise<void> {
  const json = JSON.stringify(data, null, 2);
  await writeFilePath(filePath, json, 'application/json');
}

// ─── Root structure ───────────────────────────────────────────────────────────

export async function initRootStructure(): Promise<void> {
  const r = root();
  await ensureFolder(r);
  await ensureFolder(`${r}/_Skills`);
  await ensureFolder(`${r}/Affaires`);
  await ensureFolder(`${r}/Bibliotheque`);
  for (const d of ['Commercial','Fiscal','Social','Civil','Penal','Immobilier','International']) {
    await ensureFolder(`${r}/Bibliotheque/${d}`);
  }
}

// ─── Skills ───────────────────────────────────────────────────────────────────

export async function loadSkills(): Promise<Array<{ name: string; content: string }>> {
  const r = root();
  let items: GraphDriveItem[];
  try { items = await listFolder(`${r}/_Skills`); } catch { return []; }
  const skills: Array<{ name: string; content: string }> = [];
  for (const item of items) {
    if (item.folder) continue;
    const ext = item.name.split('.').pop()?.toLowerCase() ?? '';
    if (!['md','txt'].includes(ext)) continue;
    try {
      const buf = await readFilePath(`${r}/_Skills/${item.name}`);
      skills.push({ name: item.name, content: new TextDecoder().decode(buf) });
    } catch {}
  }
  return skills;
}

// ─── Case operations ──────────────────────────────────────────────────────────

export function casePath(folderName: string): string {
  return `${root()}/Affaires/${folderName}`;
}
function metaPath(folderName: string)     { return `${casePath(folderName)}/_meta.json`; }
function notesPath(folderName: string)    { return `${casePath(folderName)}/_notes.json`; }
function convPath(folderName: string)     { return `${casePath(folderName)}/_conversation.json`; }

export async function listCaseFolders(): Promise<string[]> {
  const r = root();
  try {
    const items = await listFolder(`${r}/Affaires`);
    return items.filter(i => i.folder).map(i => i.name);
  } catch { return []; }
}

export async function readCaseMeta(folderName: string): Promise<CaseMeta | null> {
  return readJson<CaseMeta>(metaPath(folderName));
}

export async function writeCaseMeta(folderName: string, meta: CaseMeta): Promise<void> {
  await ensureFolder(casePath(folderName));
  await writeJson(metaPath(folderName), meta);
}

export async function readNotes(folderName: string): Promise<PermanentNote[]> {
  const f = await readJson<NotesFile>(notesPath(folderName));
  return f?.notes ?? [];
}

export async function writeNotes(folderName: string, notes: PermanentNote[]): Promise<void> {
  await writeJson(notesPath(folderName), { notes } satisfies NotesFile);
}

export async function readConversation(folderName: string): Promise<ChatMessage[]> {
  const f = await readJson<ConversationFile>(convPath(folderName));
  return f?.messages ?? [];
}

export async function writeConversation(folderName: string, messages: ChatMessage[]): Promise<void> {
  await writeJson(convPath(folderName), { messages } satisfies ConversationFile);
}

export async function listCaseFiles(folderName: string): Promise<GraphDriveItem[]> {
  const items = await listFolder(casePath(folderName));
  return items.filter(i => i.file && !i.name.startsWith('_'));
}

export async function readCaseFile(folderName: string, fileName: string): Promise<ArrayBuffer> {
  return readFilePath(`${casePath(folderName)}/${fileName}`);
}

export async function writeCaseFile(
  folderName: string, fileName: string, data: ArrayBuffer, mimeType: string
): Promise<void> {
  await ensureFolder(casePath(folderName));
  await writeFileLarge(`${casePath(folderName)}/${fileName}`, data, mimeType);
}

export async function deleteCaseFile(folderName: string, fileName: string): Promise<void> {
  await deleteFilePath(`${casePath(folderName)}/${fileName}`);
}

// ─── Library operations ───────────────────────────────────────────────────────

function libDomainFolder(domain: string): string {
  const cap = domain.charAt(0).toUpperCase() + domain.slice(1);
  return `${root()}/Bibliotheque/${cap}`;
}
function libMetaPath(domain: string)  { return `${libDomainFolder(domain)}/_meta.json`; }
function libConvPath(domain: string)  { return `${libDomainFolder(domain)}/_conversation.json`; }

export async function readLibMeta(domain: string): Promise<LibDomainMeta | null> {
  return readJson<LibDomainMeta>(libMetaPath(domain));
}

export async function writeLibMeta(domain: string, meta: LibDomainMeta): Promise<void> {
  await ensureFolder(libDomainFolder(domain));
  await writeJson(libMetaPath(domain), meta);
}

export async function readLibConversation(domain: string): Promise<LibConversationMessage[]> {
  // 'all' domain conversation stored at root Bibliotheque level
  const path = domain === 'all'
    ? `${root()}/Bibliotheque/_conversation.json`
    : libConvPath(domain);
  const f = await readJson<{ messages: LibConversationMessage[] }>(path);
  return f?.messages ?? [];
}

export async function writeLibConversation(domain: string, messages: LibConversationMessage[]): Promise<void> {
  const path = domain === 'all'
    ? `${root()}/Bibliotheque/_conversation.json`
    : libConvPath(domain);
  await writeJson(path, { messages });
}

export async function listLibFiles(domain: string): Promise<GraphDriveItem[]> {
  try {
    const items = await listFolder(libDomainFolder(domain));
    return items.filter(i => i.file && !i.name.startsWith('_'));
  } catch { return []; }
}

export async function readLibFile(domain: string, fileName: string): Promise<ArrayBuffer> {
  return readFilePath(`${libDomainFolder(domain)}/${fileName}`);
}

export async function writeLibFile(
  domain: string, fileName: string, data: ArrayBuffer, mimeType: string
): Promise<void> {
  await ensureFolder(libDomainFolder(domain));
  await writeFileLarge(`${libDomainFolder(domain)}/${fileName}`, data, mimeType);
}
